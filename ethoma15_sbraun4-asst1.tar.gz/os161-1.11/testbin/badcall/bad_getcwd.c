/*
 * __getcwd
 */

#include "test.h"

void
test_getcwd(void)
{
	test_getcwd_buf();
}
